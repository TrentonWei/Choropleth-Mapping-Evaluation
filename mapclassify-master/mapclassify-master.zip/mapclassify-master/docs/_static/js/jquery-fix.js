// No Conflict in later (our) version of jQuery
window.$jqTheme = jQuery.noConflict(true);